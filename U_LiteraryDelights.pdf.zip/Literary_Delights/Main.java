import classes.*;

import java.lang.*;
public class Main{
public static void main(String[] args) {
         new SplashScreenFrame(2000);
		  //new Login();
		
    }
	}