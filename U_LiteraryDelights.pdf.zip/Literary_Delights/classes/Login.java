package classes;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.FileNotFoundException; 
import java.lang.*;

 public class Login extends JFrame implements ActionListener {

    private Font fontstyle1,fontstyle2;
    private JButton login,signup,forgotPass;
    private JTextField emailField;
    private JPasswordField passwordField;
    public FileReader reader;
    public String email_to_check;
    private JFrame f;
	private Cursor cursor;
	
	public String get_email()
	{
		return email_to_check;
	}

    

    public Login() {
        f = new JFrame("Login Screen");

        //font
		fontstyle1 = new Font("Verdana", Font.BOLD, 36);
		fontstyle2= new Font("Helvetica", Font.PLAIN, 15);

	//Cursor for JButtons
		
		cursor = new Cursor(Cursor.HAND_CURSOR);

        JLabel emailLabel = new JLabel("Email Address");
        emailLabel.setBounds(670,200,273,40);
        emailLabel.setFont(fontstyle2);

        emailField = new JTextField();
        emailField.setBounds(670,240,273,40);
        emailField.setBorder(null);

        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setBounds(670,290,273,40);
        passwordLabel.setFont(fontstyle2);

        passwordField = new JPasswordField();
        passwordField.setBounds(670,330,273,40);
        passwordField.setBorder(null);

        login = new JButton("Login");
        login.setBounds(770, 410, 80, 30);
        login.setBorderPainted(false);
        login.setBackground(Color.BLACK);
        login.setForeground(Color.GRAY);
        ImageIcon icon1 = new ImageIcon("Images\\Log In1.png");
        login.setIcon(icon1);
		login.setCursor(cursor);
        login.addActionListener(this);

        final JLabel label1 = new JLabel("Login!");
        label1.setBounds(740, 140, 273,60);
        label1.setFont(fontstyle1);
		
		
		final JLabel label2 = new JLabel("Don't have a account?");
        label2.setBounds(690, 460, 150,30);
        label2.setFont(fontstyle2);

        signup = new JButton("SignUp Now");
        signup.setBounds(825, 460, 115, 30);
        signup.setBorderPainted(false);
        signup.setForeground(Color.BLUE);
		signup.setOpaque(false);
		signup.setContentAreaFilled(false);
		signup.setCursor(cursor);
		//ImageIcon icon = new ImageIcon("Images\\Signup.png");
        //signup.setIcon(icon);
        signup.addActionListener(this);

        forgotPass = new JButton("Forgot password?");
        forgotPass.setBounds(785, 370, 200, 35);
        forgotPass.setBorderPainted(false);
        forgotPass.setForeground(Color.BLUE);
        forgotPass.setOpaque(false);
        forgotPass.setContentAreaFilled(false);
		forgotPass.setCursor(cursor);
        forgotPass.addActionListener(this);

       

        JLabel background;
        ImageIcon img = new ImageIcon("Images//Login Logo.png");
        background = new JLabel("", img, JLabel.CENTER);
        background.setBounds(0, 0, 1070, 645);

        f.add(passwordField);
        f.add(emailLabel);
        f.add(label1);
		f.add(label2);
        f.add(passwordLabel);
        f.add(login);
        f.add(signup);
        f.add(forgotPass);
        f.add(emailField);
        f.add(background);

        f.setSize(1080, 650);
        f.setLayout(null);
        f.setLocationRelativeTo(null);
        f.setVisible(true);
		f.setResizable(false);
        f.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource()==login)
		{
			 String email=emailField.getText();
			 String password=passwordField.getText();
			 
			 
			 String LoginInfo =email+","+password;
			 
			 String AmdinLoginInfo ="admin"+","+"admin";
			 
			BufferedReader bfreader=null;
			String line;
			int count=0;
			try
			{
				reader=new FileReader("AllTextFiles/UserInfo.txt");
				bfreader=new BufferedReader(reader);
				
				while((line=bfreader.readLine())!=null)
				{
					String[] parts = line.split(",");
					String Email = parts[0];
					String Password = parts[1];
					
					String User_login_info= Email+","+Password;

					if(LoginInfo.equals(User_login_info))
					{
						count++;
					}				
				}
				
				if(email.isEmpty() || password.isEmpty())
				{
					JOptionPane.showMessageDialog(this,"Please fill up all the fields");
				}
				
				else if(count==1)
				{
					email_to_check= emailField.getText();
					f.setVisible(false);
					new HomePage(this);
				}
				else if (LoginInfo.equals(AmdinLoginInfo))
				{
					f.setVisible(false);
					new Admin();
				}
				
				
				else
				{
					JOptionPane.showMessageDialog(this,"Enter Correct ID & Password");
				}
				
								
				reader.close();
				bfreader.close();
			}
			catch(Exception ex)
			{
				System.out.println(ex);
			}
		}
	
	
		else if(e.getSource()==signup)
		{
			f.setVisible(false);
			new SignUp();
		}
		
		else if(e.getSource()==forgotPass)
		{
			f.setVisible(false);
			//new Forgot();
		}
		
		
	}
}

      

		
    
