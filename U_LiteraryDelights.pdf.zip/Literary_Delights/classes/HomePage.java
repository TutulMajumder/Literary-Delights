package classes;

import javax.swing.*;    
import java.awt.event.*;  
import java.awt.*;
import javax.swing.ImageIcon;
import javax.imageio.*;
import java.io.File; 
import java.io.FileWriter;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.FileNotFoundException; 
import java.lang.*;
import java.awt.Color;
import java.util.Scanner;
import javax.swing.border.*;
import java.util.*;

public class HomePage extends JFrame implements ActionListener
{
	private JFrame HomePageFrame;
	
	// Fonts collection
	Font font30 = new Font("Cambria", Font.BOLD, 30);
	Font font25 = new Font("Cambria", Font.BOLD, 25);
	Font font20 = new Font("Cambria", Font.BOLD, 20);
	Font font15 = new Font("Cambria", Font.BOLD, 15);
	Font font12 = new Font("Cambria", Font.BOLD, 12);
	Font font36 = new Font("Verdana", Font.BOLD, 36);
	
	
	
	JLabel idLabel1,idLabel2,idLabel3,idLabel4,idLabel5,idLabel6;
	
	
	private JTextField searchTextField;
	private JButton ProfileButton, LogoutButton, SearchButton,ContactUsButton,AboutUsButton;
	
	private JButton B1,B2,B3,B4,B5,B6,B7,B8,B9,B10,B11,B12;
	private Cursor cursor;
    public static int a=0;
	public static String info [];
	private Login login;
	//public String Email_Address;

		
	public HomePage(Login login)
	{
		HomePageFrame=new JFrame("HomePage");
		
		this.login=login;
		//Email_Address=login.get_email();
		
		//Cursor for JButtons
		 cursor = new Cursor(Cursor.HAND_CURSOR);
		
		//Title
	    JLabel TitleLabel1=new JLabel("LITERARY");
		//TitleLabel1.setOpaque(true);
		TitleLabel1.setBounds(75,0,300,50);
		TitleLabel1.setFont(font25);
		
		JLabel TitleLabel2=new JLabel("DELIGHTS");
		//TitleLabel2.setOpaque(true);
		TitleLabel2.setBounds(30,30,300,50);
		TitleLabel2.setFont(font36);
	
		
		
		
	/*
	//Book Search
	
	
	    JLabel searchLabel = new JLabel("Search By Book ID");
		searchLabel.setOpaque(false);
        searchLabel.setBounds(350,0,150,30);
        searchLabel.setFont(font12);
        
		

        searchTextField = new JTextField();
        searchTextField.setBounds(350,32,220,40);
		searchTextField .setOpaque(true);
		searchTextField.setForeground(Color.white);
		
	*/
		
		
	
		
		
		
		
		
		
	
	
	
	
	
		
		
	//Button Create
	
	/*
	//searchButton
	    SearchButton=new JButton();
        SearchButton.setBounds(590, 32, 100, 40);
        SearchButton.setBorderPainted(false);
		SearchButton.setContentAreaFilled(true);
		SearchButton.setCursor(cursor);
		ImageIcon icon = new ImageIcon("Images\\SearchL.png");
        SearchButton.setIcon(icon);
		SearchButton.addActionListener(this);
		*/
	//Profile Button	
		ProfileButton=new JButton();
        ProfileButton.setBounds(560, 32, 100, 40);
        ProfileButton.setBorderPainted(false);
		ProfileButton.setContentAreaFilled(false);
		ProfileButton.setCursor(cursor);
		ImageIcon icon2 = new ImageIcon("Images\\Profile.png");
        ProfileButton.setIcon(icon2);
		ProfileButton.addActionListener(this);
		
		
	//LogoutButton
	    LogoutButton=new JButton();
        LogoutButton.setBounds(680, 32, 100, 40);
        LogoutButton.setBorderPainted(false);
		LogoutButton.setContentAreaFilled(false);
		LogoutButton.setCursor(cursor);
		ImageIcon icon3 = new ImageIcon("Images\\LogOut.png");
        LogoutButton.setIcon(icon3);
		LogoutButton.addActionListener(this);
	//ContactUs Button
	    ContactUsButton=new JButton();
        ContactUsButton.setBounds(800, 32, 100, 40);
        ContactUsButton.setBorderPainted(false);
		ContactUsButton.setContentAreaFilled(false);
		ContactUsButton.setCursor(cursor);
		ImageIcon icon4 = new ImageIcon("Images\\ContactUs.png");
        ContactUsButton.setIcon(icon4);
		ContactUsButton.addActionListener(this);
		
	//AboutUs Button
	    AboutUsButton=new JButton();
        AboutUsButton.setBounds(920, 32, 100, 40);
        AboutUsButton.setBorderPainted(false);
		AboutUsButton.setContentAreaFilled(false);
		AboutUsButton.setCursor(cursor);
		ImageIcon icon5 = new ImageIcon("Images\\AboutUs.png");
        AboutUsButton.setIcon(icon5);
		AboutUsButton.addActionListener(this);
		
		
		
		//Book Catagory Button
		
		B1=new JButton();
        B1.setBounds(100, 120, 200,200);
		B1.setCursor(cursor);
		ImageIcon icon11 = new ImageIcon("Images\\C story.JPG");
        B1.setIcon(icon11);
		B1.setBorderPainted(false);
		B1.setContentAreaFilled(true);
		B1.setFocusable(false);
		B1.addActionListener(this);

		
		B2=new JButton();
        B2.setBounds(440, 120, 200,200);
		B2.setCursor(cursor);
		ImageIcon icon12 = new ImageIcon("Images\\CNovel.JPG");
        B2.setIcon(icon12);
		B2.setBorderPainted(false);
		B2.setContentAreaFilled(true);
		//B1.setFocusable(false);
		B2.addActionListener(this);
		
		B3=new JButton();
        B3.setBounds(780, 120, 200,200);
		B3.setCursor(cursor);
		ImageIcon icon13 = new ImageIcon("Images\\Drama.JPG");
        B3.setIcon(icon13);
		B3.setBorderPainted(false);
		B3.setContentAreaFilled(true);
		//B1.setFocusable(false);
		B3.addActionListener(this);
		
		B4=new JButton();
        B4.setBounds(100, 360, 200,200);
		B4.setCursor(cursor);
		ImageIcon icon14 = new ImageIcon("Images\\Myatery.JPG");
        B4.setIcon(icon14);
		B4.setBorderPainted(false);
		B4.setContentAreaFilled(true);
		//B1.setFocusable(false);
		B4.addActionListener(this);
		
		
		B5=new JButton();
        B5.setBounds(440, 360, 200,200);
		B5.setCursor(cursor);
		ImageIcon icon15 = new ImageIcon("Images\\ShortStory.JPG");
        B5.setIcon(icon15);
		B5.setBorderPainted(false);
		B5.setContentAreaFilled(true);
		//B1.setFocusable(false);
		B5.addActionListener(this);
		
		B6=new JButton();
        B6.setBounds(780, 360, 200,200);
		B6.setCursor(cursor);
		ImageIcon icon16 = new ImageIcon("Images\\Poetry.JPG");
        B6.setIcon(icon16);
		B6.setBorderPainted(false);
		B6.setContentAreaFilled(true);
		//B1.setFocusable(false);
		B6.addActionListener(this);
		
	
		
		
		//Book Id Label
	    idLabel1 = new JLabel("UPONNASH");
		idLabel1.setBounds(150,330,200,15);
		idLabel1.setFont(font20);
		
		idLabel2 = new JLabel("DRAMA");
		idLabel2.setBounds(500,330,200,15);
		idLabel2.setFont(font20);
		
		idLabel3 = new JLabel("SHORT STORY");
		idLabel3.setBounds(820,330,200,15);
		idLabel3.setFont(font20);
		
		idLabel4 = new JLabel("POETRY");
		idLabel4.setBounds(150,570,200,15);
		idLabel4.setFont(font20);
		
		idLabel5 = new JLabel("THRILLER");
		idLabel5.setBounds(500,570,200,15);
		idLabel5.setFont(font20);
		
		idLabel6 = new JLabel("MYSTERY");
		idLabel6.setBounds(840,570,200,15);
		idLabel6.setFont(font20);
		
		
		
		
		
	   info = new String [100];
	   try
		{
			Scanner sc = new Scanner(new File("AllTextFiles/BookInfo.txt"));
			
			while(sc.hasNextLine())
			{
				String st = sc.nextLine();
				for(int i=0; i<info.length; i++)
				{
					if(info[i]==null)
					{
						info[i]=st;
						break;
					}
					
				}
			}
			sc.close();
		}
		catch(Exception ex)
		{
			
		}
		
		
	
	
	
	
	
	// Create panel
		JPanel panel1 = new JPanel();
		panel1.setBounds(0,0,1080,100);
		panel1.setBackground(Color.ORANGE);
		
		
		JPanel panel2 = new JPanel();
	    panel2.setBounds(0, 0, 1080, 650);
		panel2.setBackground(Color.WHITE);
		
		
	//Adding Components
	HomePageFrame.add(TitleLabel1);
	HomePageFrame.add(TitleLabel2);
	
	/*HomePageFrame.add(searchLabel);
	HomePageFrame.add(searchTextField);
	HomePageFrame.add(SearchButton);*/
	
	
	HomePageFrame.add(ProfileButton);
	HomePageFrame.add(LogoutButton);
	HomePageFrame.add(ContactUsButton);
	HomePageFrame.add(AboutUsButton);
	
	
	//BOOK COMPONENTS
	HomePageFrame.add(B1);
	HomePageFrame.add(B2);
	HomePageFrame.add(B3);
	HomePageFrame.add(B4);
	HomePageFrame.add(B5);
	HomePageFrame.add(B6);
	
	
	//label
	HomePageFrame.add(idLabel1);
	HomePageFrame.add(idLabel2);
	HomePageFrame.add(idLabel3);
	HomePageFrame.add(idLabel4);
	HomePageFrame.add(idLabel5);
	HomePageFrame.add(idLabel6);
	
	
	
	
	
	
	
	
	
	
	
	
	
	HomePageFrame.add(panel1);
	HomePageFrame.add(panel2);
	
	
	
	
	//HomePageFrame.add(TitleLabel);
	
		
		
		
		
		
		
		
	
		
		
		
		//HomePageFrame Properties
	    HomePageFrame.setSize(1080, 650);
        HomePageFrame.setLayout(null);
        HomePageFrame.setLocationRelativeTo(null);
        HomePageFrame.setVisible(true);
		HomePageFrame.setResizable(false);
        HomePageFrame.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}
	
	public void actionPerformed(ActionEvent e) 
	{
		
		if(e.getSource()==ProfileButton)
		{
			HomePageFrame.setVisible(false);
			new Profile(login,this);
		}
		
		
		else if(e.getSource()==LogoutButton)
		{
			
			//this.dispose();
			HomePageFrame.setVisible(false);
			//login.setVisible(true);
			//System.exit(0);
			//this.setVisible(false);
			new Login();
		}
		
		
		else if(e.getSource()==AboutUsButton)
		{
			HomePageFrame.setVisible(false);
			new AboutUs(this,login);
		}
		
		else if(e.getSource()==ContactUsButton)
		{
			HomePageFrame.setVisible(false);
			new ContactUs(this,login);
		}
		
		else if(e.getSource()==B1)
		{
			HomePageFrame.setVisible(false);
			new UponashF(this,login);
		}
		
		
		else if(e.getSource()==B2)
		{
			HomePageFrame.setVisible(false);
			new DramaF(this,login);
			
		}
		
		else if(e.getSource()==B3)
		{
			HomePageFrame.setVisible(false);
			new ShortStoryF(this,login);
		}
		else if(e.getSource()==B4)
		{
			HomePageFrame.setVisible(false);
			new ThrillerF(this,login);
		}
		else if(e.getSource()==B5)
		{
			HomePageFrame.setVisible(false);
			new PoetryF(this,login);
		}
		else if(e.getSource()==B6)
		{
			HomePageFrame.setVisible(false);
			new MysteryF(this,login);
		}
		
		
	}
		
	
}