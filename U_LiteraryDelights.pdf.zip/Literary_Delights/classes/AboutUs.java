package classes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AboutUs extends JFrame implements ActionListener
{
	JButton BackButton;
	JPanel p1,p2;
	HomePage home;
	Login login;
	
  public  AboutUs(HomePage home,Login login)
	{
    super(" About us ");
	this.home=home;
	this.login = login;
	this.setSize(550,400);
	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	this.setResizable(false);
	this.setLayout(null);
		
	p1 = new JPanel();
	p1.setBounds(0,0,550,400);
	p1.setBackground(Color.decode("#99eaff"));
	this.setLocationRelativeTo(null);
	p1.setBackground(Color.WHITE);
	p1.setLayout(null);
	
//JPanel
    p2 = new JPanel();
	p2.setBounds(0, 300, 550, 80);
	this.setLocationRelativeTo(null);
	p2.setBackground(Color.WHITE);
	//p2.setBackground(Color.decode("#99eaff"));
	p2.setLayout(null);
		
		
    JTextArea terms = new JTextArea();
	terms.setBounds(10,0,545,300);
	terms.setBackground(Color.WHITE);
	//terms.setBackground(Color.decode("#99eaff"));
    terms.setText("\n" +
                     "                                    Welcome to Literary Delights\n" +
                     "  *At Literary Delights, we believe in the transformative power of literature. Our\n online bookshop is a haven for book enthusiasts,a virtual realm where stories come \n alive,ideas flourish, and literary wonders await exploration.\n" +
                     "                                  Join the Literary Delights Community\n"+
                     "   *Become a part of our community of literary enthusiasts. Follow us on social \n media. Together, let's celebrate the joy of reading and the magic that unfolds within the \n pages of a good book.\n"+
					 "   *Thank you for choosing Literary Delights Online Bookshop. We invite you to \n immerse yourself in the world of literature and discover the endless delights that\n await you.\n"+
					 "Happy Reading!\n"+
                     "The Literary Delights Team");
					 
    terms.setEditable(false);
    terms.setFont(new Font("Segoe UI",Font.PLAIN,14));
    p1.add(terms);
		
//JButton	
    BackButton = new JButton("BACK");
	BackButton.setFont(new Font("Segoe UI",Font.BOLD,15));
	BackButton.setForeground(Color.BLACK);
	BackButton.setBounds(220,5,90,30); 
	BackButton.addActionListener(this);
	BackButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	p2.add(BackButton);
   	
	
    p1.add(p2);
    this.add(p1);
    setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource()==BackButton)
		{
         //this.dispose();
		 //home.setVisible(true);
		 this.setVisible(false);
		 new HomePage(login);
			
		}
	}

 
		
}